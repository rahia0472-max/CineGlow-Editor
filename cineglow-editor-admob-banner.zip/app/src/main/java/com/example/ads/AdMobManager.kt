package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.CineSurface
import com.example.ui.theme.CineTextMuted
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * AdMob integration manager for CineGlow Editor.
 * Includes Banner and Interstitial ad support.
 * The Banner uses the provided AdMob Banner Ad Unit ID; interstitial remains on the official test ID.
 */
object AdMobManager {

    private const val TAG = "AdMobManager"

    // Official Google AdMob Test Ad Unit IDs
    const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-6640126693956932/6558366537"
    const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    private var isInitialized = false

    /**
     * Initializes Google Mobile Ads SDK safely without blocking UI.
     */
    fun initialize(context: Context) {
        if (isInitialized) return
        try {
            MobileAds.initialize(context) {
                isInitialized = true
                Log.d(TAG, "AdMob SDK initialized successfully.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "AdMob initialization warning: ${e.message}")
        }
    }

    /**
     * Loads and shows an interstitial ad (e.g. after a photo or video export).
     * Invokes [onDismissed] seamlessly when the ad is closed or fails to load.
     */
    fun showInterstitial(
        activity: Activity,
        adUnitId: String = TEST_INTERSTITIAL_AD_UNIT_ID,
        onDismissed: () -> Unit
    ) {
        try {
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                activity,
                adUnitId,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        interstitialAd.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                onDismissed()
                            }

                            override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                                onDismissed()
                            }
                        }
                        interstitialAd.show(activity)
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.w(TAG, "Interstitial failed to load: ${loadAdError.message}")
                        onDismissed()
                    }
                }
            )
        } catch (e: Exception) {
            Log.w(TAG, "AdMob interstitial error: ${e.message}")
            onDismissed()
        }
    }
}

/**
 * Composable Banner Ad component that integrates Google AdMob Banner smoothly into Compose layouts.
 */
@Composable
fun AdMobBanner(
    modifier: Modifier = Modifier,
    adUnitId: String = AdMobManager.TEST_BANNER_AD_UNIT_ID
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(CineSurface),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxWidth(),
            factory = { context ->
                AdView(context).apply {
                    setAdSize(AdSize.BANNER)
                    setAdUnitId(adUnitId)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    adListener = object : AdListener() {
                        override fun onAdFailedToLoad(adError: LoadAdError) {
                            Log.d("AdMobBanner", "Banner ad failed: ${adError.message}")
                        }
                    }
                    try {
                        loadAd(AdRequest.Builder().build())
                    } catch (e: Exception) {
                        Log.w("AdMobBanner", "Failed to load banner: ${e.message}")
                    }
                }
            }
        )
    }
}
