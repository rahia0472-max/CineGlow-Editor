package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.AdMobManager
import com.example.model.CineFilter
import com.example.model.CropAspectRatio
import com.example.photo.BitmapUtils
import com.example.photo.PhotoEditState
import com.example.ui.components.AdjustmentSliderRow
import com.example.ui.components.AspectRatioChip
import com.example.ui.components.FilterPresetItem
import com.example.ui.components.ProcessingDialog
import com.example.ui.theme.CineAmber
import com.example.ui.theme.CineAmberGlow
import com.example.ui.theme.CineBorder
import com.example.ui.theme.CineCyan
import com.example.ui.theme.CineObsidian
import com.example.ui.theme.CineSurface
import com.example.ui.theme.CineSurfaceElevated
import com.example.ui.theme.CineSurfaceVariant
import com.example.ui.theme.CineTextMuted
import com.example.ui.theme.CineTextPrimary
import com.example.ui.theme.CineTextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class PhotoTab(val title: String, val icon: ImageVector) {
    FILTERS("Filters", Icons.Default.Filter),
    ADJUST("Adjust", Icons.Default.Tune),
    SKIN("Skin Glow", Icons.Default.Face),
    CROP("Crop & Ratio", Icons.Default.Crop)
}

@Composable
fun PhotoEditorScreen(
    initialUri: Uri,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activity = context as? Activity

    var currentUri by remember { mutableStateOf(initialUri) }
    var loadedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isLoadingImage by remember { mutableStateOf(true) }
    var isSaving by remember { mutableStateOf(false) }

    // Undo / Redo history stacks
    var currentState by remember { mutableStateOf(PhotoEditState()) }
    val undoStack = remember { mutableListOf<PhotoEditState>() }
    val redoStack = remember { mutableListOf<PhotoEditState>() }

    // Temporary touch-and-hold to view unedited original
    var isComparingOriginal by remember { mutableStateOf(false) }

    var selectedTab by remember { mutableStateOf(PhotoTab.FILTERS) }

    // Photo picker for switching photo
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { newUri: Uri? ->
        newUri?.let {
            currentUri = it
            undoStack.clear()
            redoStack.clear()
            currentState = PhotoEditState()
        }
    }

    // Load bitmap safely on URI change
    LaunchedEffect(currentUri) {
        isLoadingImage = true
        val bmp = BitmapUtils.decodeSampledBitmapFromUri(context, currentUri)
        loadedBitmap = bmp
        isLoadingImage = false
    }

    // Helper to push state changes into undo stack
    fun updateState(newState: PhotoEditState) {
        if (newState != currentState) {
            undoStack.add(currentState)
            redoStack.clear()
            currentState = newState
        }
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.add(currentState)
            currentState = undoStack.removeAt(undoStack.lastIndex)
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.add(currentState)
            currentState = redoStack.removeAt(redoStack.lastIndex)
        }
    }

    fun reset() {
        if (!currentState.isDefault()) {
            undoStack.add(currentState)
            redoStack.clear()
            currentState = PhotoEditState()
            Toast.makeText(context, "All adjustments reset", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveToGallery() {
        val src = loadedBitmap ?: return
        isSaving = true
        scope.launch {
            try {
                val processed = BitmapUtils.processEditedBitmap(src, currentState)
                val savedUri = BitmapUtils.saveImageToGallery(context, processed)

                withContext(Dispatchers.Main) {
                    isSaving = false
                    if (savedUri != null) {
                        Toast.makeText(context, "Saved to Gallery (Pictures/CineGlow)", Toast.LENGTH_LONG).show()

                        // Trigger AdMob Interstitial
                        activity?.let {
                            AdMobManager.showInterstitial(it) {
                                // Ad dismissed
                            }
                        }
                    } else {
                        Toast.makeText(context, "Failed to save photo.", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isSaving = false
                    Toast.makeText(context, "Error saving: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CineObsidian)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // TOP APP BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CineSurface)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = CineTextPrimary
                    )
                }
                Text(
                    text = "Photo Editor",
                    color = CineTextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Change photo
                IconButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = "Change Photo",
                        tint = CineTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Undo
                IconButton(
                    onClick = { undo() },
                    enabled = undoStack.isNotEmpty()
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Undo,
                        contentDescription = "Undo",
                        tint = if (undoStack.isNotEmpty()) CineAmber else CineTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Redo
                IconButton(
                    onClick = { redo() },
                    enabled = redoStack.isNotEmpty()
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Redo,
                        contentDescription = "Redo",
                        tint = if (redoStack.isNotEmpty()) CineAmber else CineTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Reset
                IconButton(
                    onClick = { reset() },
                    enabled = !currentState.isDefault()
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = "Reset",
                        tint = if (!currentState.isDefault()) CineAmber else CineTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Save
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CineAmber)
                        .clickable(onClick = { saveToGallery() })
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save",
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Save",
                            color = Color.Black,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // PHOTO PREVIEW AREA
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (isLoadingImage) {
                CircularProgressIndicator(color = CineAmber)
            } else if (loadedBitmap != null) {
                val bitmap = loadedBitmap!!
                val colorFilter = if (isComparingOriginal) {
                    null
                } else {
                    ColorFilter.colorMatrix(currentState.computeColorMatrix())
                }

                // Crop aspect ratio box framing
                val targetRatio = currentState.aspectRatio.ratio
                val imageAspect = if (currentState.rotationDegrees % 180 == 0) {
                    bitmap.width.toFloat() / bitmap.height.toFloat()
                } else {
                    bitmap.height.toFloat() / bitmap.width.toFloat()
                }

                Box(
                    modifier = Modifier
                        .padding(12.dp)
                        .then(
                            if (targetRatio != null) {
                                Modifier.aspectRatio(targetRatio)
                            } else {
                                Modifier
                            }
                        )
                        .border(
                            if (targetRatio != null) 1.dp else 0.dp,
                            if (targetRatio != null) CineAmber.copy(alpha = 0.5f) else Color.Transparent
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Photo Preview",
                        colorFilter = colorFilter,
                        contentScale = if (targetRatio != null) ContentScale.Crop else ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(currentState.rotationDegrees.toFloat())
                    )
                }

                // Touch & hold "Original" comparison button
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(CineSurface.copy(alpha = 0.85f))
                        .border(1.dp, CineBorder, RoundedCornerShape(20.dp))
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    isComparingOriginal = true
                                    tryAwaitRelease()
                                    isComparingOriginal = false
                                }
                            )
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = "Hold for original",
                            tint = if (isComparingOriginal) CineAmber else CineTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isComparingOriginal) "ORIGINAL" else "Hold: Original",
                            color = if (isComparingOriginal) CineAmberGlow else CineTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                Text("Unable to load image.", color = CineTextMuted)
            }
        }

        // TOOLBAR DRAWER (FILTERS / ADJUST / SKIN / CROP)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CineSurface)
                .border(1.dp, CineBorder)
        ) {
            // Tab Content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
            ) {
                when (selectedTab) {
                    PhotoTab.FILTERS -> {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CineFilter.entries.forEach { filter ->
                                FilterPresetItem(
                                    filter = filter,
                                    isSelected = currentState.filter == filter,
                                    onClick = {
                                        updateState(currentState.copy(filter = filter))
                                    }
                                )
                            }
                        }
                    }

                    PhotoTab.ADJUST -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(vertical = 6.dp)
                        ) {
                            AdjustmentSliderRow(
                                title = "Brightness",
                                value = currentState.brightness,
                                range = -100f..100f,
                                onValueChange = { updateState(currentState.copy(brightness = it)) }
                            )
                            AdjustmentSliderRow(
                                title = "Contrast",
                                value = currentState.contrast,
                                range = -100f..100f,
                                onValueChange = { updateState(currentState.copy(contrast = it)) }
                            )
                            AdjustmentSliderRow(
                                title = "Saturation",
                                value = currentState.saturation,
                                range = -100f..100f,
                                onValueChange = { updateState(currentState.copy(saturation = it)) }
                            )
                            AdjustmentSliderRow(
                                title = "Warmth / Temp",
                                value = currentState.warmth,
                                range = -100f..100f,
                                onValueChange = { updateState(currentState.copy(warmth = it)) }
                            )
                            AdjustmentSliderRow(
                                title = "Highlights",
                                value = currentState.highlights,
                                range = -100f..100f,
                                onValueChange = { updateState(currentState.copy(highlights = it)) }
                            )
                            AdjustmentSliderRow(
                                title = "Shadows",
                                value = currentState.shadows,
                                range = -100f..100f,
                                onValueChange = { updateState(currentState.copy(shadows = it)) }
                            )
                            AdjustmentSliderRow(
                                title = "Sharpness",
                                value = currentState.sharpness,
                                range = 0f..100f,
                                onValueChange = { updateState(currentState.copy(sharpness = it)) }
                            )
                        }
                    }

                    PhotoTab.SKIN -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Natural Skin Glow & Smoothing",
                                color = CineTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Gently smooths complexion and illuminates skin tone naturally without altering facial identity.",
                                color = CineTextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            AdjustmentSliderRow(
                                title = "Skin Tone Polish",
                                value = currentState.skinEnhance,
                                range = 0f..100f,
                                onValueChange = { updateState(currentState.copy(skinEnhance = it)) }
                            )
                        }
                    }

                    PhotoTab.CROP -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Aspect Ratio & Orientation",
                                    color = CineTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                // 90° Rotate button
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CineSurfaceElevated)
                                        .clickable {
                                            val nextRotation = (currentState.rotationDegrees + 90) % 360
                                            updateState(currentState.copy(rotationDegrees = nextRotation))
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RotateRight,
                                        contentDescription = "Rotate 90°",
                                        tint = CineAmber,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${currentState.rotationDegrees}°",
                                        color = CineTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CropAspectRatio.entries.forEach { ratio ->
                                    AspectRatioChip(
                                        aspectRatio = ratio,
                                        isSelected = currentState.aspectRatio == ratio,
                                        onClick = {
                                            updateState(currentState.copy(aspectRatio = ratio))
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // BOTTOM NAVIGATION TABS
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CineSurfaceVariant)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                PhotoTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    val tint = if (isSelected) CineAmber else CineTextMuted

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedTab = tab }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = tint,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = tab.title,
                            color = tint,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }

    // Saving Dialog
    if (isSaving) {
        ProcessingDialog(
            title = "Rendering & Saving",
            message = "Applying studio grade filters & saving to Gallery..."
        )
    }
}
