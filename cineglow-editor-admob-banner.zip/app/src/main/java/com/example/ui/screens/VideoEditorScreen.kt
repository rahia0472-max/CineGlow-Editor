package com.example.ui.screens

import android.app.Activity
import android.net.Uri
import android.os.Build
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.ads.AdMobBanner
import com.example.ads.AdMobManager
import com.example.model.CineFilter
import com.example.model.CropAspectRatio
import com.example.ui.components.AdjustmentSliderRow
import com.example.ui.components.AspectRatioChip
import com.example.ui.components.FilterPresetItem
import com.example.ui.components.ProcessingDialog
import com.example.ui.theme.CineAmber
import com.example.ui.theme.CineAmberGlow
import com.example.ui.theme.CineBorder
import com.example.ui.theme.CineCyan
import com.example.ui.theme.CineObsidian
import com.example.ui.theme.CineSurface
import com.example.ui.theme.CineSurfaceElevated
import com.example.ui.theme.CineSurfaceVariant
import com.example.ui.theme.CineTextMuted
import com.example.ui.theme.CineTextPrimary
import com.example.ui.theme.CineTextSecondary
import com.example.video.VideoEditState
import com.example.video.VideoExporter
import kotlinx.coroutines.delay

private enum class VideoTab(val title: String, val icon: ImageVector) {
    TRIM("Trim", Icons.Default.ContentCut),
    FILTERS("Filters", Icons.Default.Filter),
    ADJUST("Adjust", Icons.Default.Tune),
    RATIO("Ratio", Icons.Default.AspectRatio)
}

@OptIn(UnstableApi::class)
@Composable
fun VideoEditorScreen(
    initialUri: Uri,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity

    var currentUri by remember { mutableStateOf(initialUri) }
    var currentState by remember { mutableStateOf(VideoEditState(uri = initialUri)) }
    var selectedTab by remember { mutableStateOf(VideoTab.TRIM) }

    // Playback state
    var isPlaying by remember { mutableStateOf(true) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }

    // Export progress state
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }

    // Video picker to switch video
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { newUri: Uri? ->
        newUri?.let {
            currentUri = it
            currentState = VideoEditState(uri = it)
        }
    }

    // Initialize ExoPlayer
    val exoPlayer = remember(currentUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(currentUri))
            prepare()
            playWhenReady = true
        }
    }

    // Monitor ExoPlayer duration and state
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    val d = exoPlayer.duration.coerceAtLeast(0L)
                    durationMs = d
                    if (currentState.durationMs == 0L || currentState.trimEndMs == 0L) {
                        currentState = currentState.copy(
                            durationMs = d,
                            trimStartMs = 0L,
                            trimEndMs = d
                        )
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Polling loop for playback tracking & trimming loop
    LaunchedEffect(exoPlayer, currentState.trimStartMs, currentState.trimEndMs) {
        while (true) {
            if (exoPlayer.isPlaying) {
                currentPositionMs = exoPlayer.currentPosition
                // Loop playback inside trim window
                if (currentState.trimEndMs > 0L && currentPositionMs >= currentState.trimEndMs) {
                    exoPlayer.seekTo(currentState.trimStartMs)
                }
            }
            delay(100)
        }
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            if (currentState.trimEndMs > 0L && currentPositionMs >= currentState.trimEndMs) {
                exoPlayer.seekTo(currentState.trimStartMs)
            }
            exoPlayer.play()
        }
    }

    fun startExport() {
        exoPlayer.pause()
        isExporting = true
        exportProgress = 0f

        VideoExporter.exportVideo(
            context = context,
            state = currentState,
            onProgress = { progress ->
                exportProgress = progress
            },
            onSuccess = { savedUri ->
                isExporting = false
                Toast.makeText(context, "Exported to Gallery (Movies/CineGlow)", Toast.LENGTH_LONG).show()

                // Trigger AdMob Interstitial Ad
                activity?.let {
                    AdMobManager.showInterstitial(it) {
                        // Dismissed
                    }
                }
            },
            onError = { errorMsg ->
                isExporting = false
                Toast.makeText(context, "Export error: $errorMsg", Toast.LENGTH_LONG).show()
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CineObsidian)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // TOP APP BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CineSurface)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = CineTextPrimary
                    )
                }
                Text(
                    text = "Video Editor",
                    color = CineTextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Change Video
                IconButton(
                    onClick = {
                        videoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Change Video",
                        tint = CineTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Reset
                IconButton(
                    onClick = {
                        currentState = VideoEditState(
                            uri = currentUri,
                            durationMs = durationMs,
                            trimStartMs = 0L,
                            trimEndMs = durationMs
                        )
                        Toast.makeText(context, "Video settings reset", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = "Reset",
                        tint = CineTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Export Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CineCyan)
                        .clickable(onClick = { startExport() })
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = "Export MP4",
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Export",
                            color = Color.Black,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // VIDEO PREVIEW VIEWPORT WITH LIVE COLOR FILTER
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            val targetRatio = currentState.aspectRatio.ratio

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .then(
                        if (targetRatio != null) {
                            Modifier.aspectRatio(targetRatio)
                        } else {
                            Modifier
                        }
                    )
                    .border(
                        if (targetRatio != null) 1.dp else 0.dp,
                        if (targetRatio != null) CineCyan.copy(alpha = 0.5f) else Color.Transparent
                    )
                    // Real-time hardware accelerated ColorMatrix filter on live video playback
                    .graphicsLayer {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            val cm = currentState.computeColorMatrix()
                            val androidCm = android.graphics.ColorMatrix(cm.values)
                            val filter = android.graphics.ColorMatrixColorFilter(androidCm)
                            renderEffect = android.graphics.RenderEffect.createColorFilterEffect(filter).asComposeRenderEffect()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                    }
                )
            }

            // Play / Pause center overlay button
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                    .clickable { togglePlayPause() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Bottom playback progress line
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatTime(currentPositionMs),
                        color = CineTextPrimary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = formatTime(durationMs),
                        color = CineTextMuted,
                        fontSize = 11.sp
                    )
                }
                Slider(
                    value = currentPositionMs.toFloat(),
                    onValueChange = { pos ->
                        currentPositionMs = pos.toLong()
                        exoPlayer.seekTo(pos.toLong())
                    },
                    valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = CineCyan,
                        activeTrackColor = CineCyan,
                        inactiveTrackColor = CineSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // TOOLBAR DRAWER (TRIM / FILTERS / ADJUST / RATIO)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CineSurface)
                .border(1.dp, CineBorder)
        ) {
            // Tab Content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
            ) {
                when (selectedTab) {
                    VideoTab.TRIM -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Video Trim Range",
                                    color = CineTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                val segmentMs = (currentState.trimEndMs - currentState.trimStartMs).coerceAtLeast(0L)
                                Text(
                                    text = "Clip: ${formatTime(segmentMs)}",
                                    color = CineCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Start position slider
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Start: ${formatTime(currentState.trimStartMs)}", color = CineTextSecondary, fontSize = 11.sp)
                                Text("End: ${formatTime(currentState.trimEndMs)}", color = CineTextSecondary, fontSize = 11.sp)
                            }

                            if (durationMs > 0L) {
                                var rangeValues by remember(currentState.trimStartMs, currentState.trimEndMs, durationMs) {
                                    mutableStateOf(
                                        currentState.trimStartMs.toFloat()..currentState.trimEndMs.coerceAtLeast(1L).toFloat()
                                    )
                                }

                                RangeSlider(
                                    value = rangeValues,
                                    onValueChange = { range ->
                                        rangeValues = range
                                        currentState = currentState.copy(
                                            trimStartMs = range.start.toLong(),
                                            trimEndMs = range.endInclusive.toLong()
                                        )
                                        exoPlayer.seekTo(range.start.toLong())
                                    },
                                    valueRange = 0f..durationMs.toFloat(),
                                    colors = SliderDefaults.colors(
                                        thumbColor = CineCyan,
                                        activeTrackColor = CineCyan,
                                        inactiveTrackColor = CineSurfaceElevated
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    VideoTab.FILTERS -> {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CineFilter.entries.forEach { filter ->
                                FilterPresetItem(
                                    filter = filter,
                                    isSelected = currentState.filter == filter,
                                    onClick = {
                                        currentState = currentState.copy(filter = filter)
                                    }
                                )
                            }
                        }
                    }

                    VideoTab.ADJUST -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(vertical = 6.dp)
                        ) {
                            AdjustmentSliderRow(
                                title = "Brightness",
                                value = currentState.brightness,
                                range = -100f..100f,
                                onValueChange = { currentState = currentState.copy(brightness = it) }
                            )
                            AdjustmentSliderRow(
                                title = "Contrast",
                                value = currentState.contrast,
                                range = -100f..100f,
                                onValueChange = { currentState = currentState.copy(contrast = it) }
                            )
                            AdjustmentSliderRow(
                                title = "Saturation",
                                value = currentState.saturation,
                                range = -100f..100f,
                                onValueChange = { currentState = currentState.copy(saturation = it) }
                            )
                        }
                    }

                    VideoTab.RATIO -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Video Aspect Ratio Crop",
                                color = CineTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CropAspectRatio.entries.forEach { ratio ->
                                    AspectRatioChip(
                                        aspectRatio = ratio,
                                        isSelected = currentState.aspectRatio == ratio,
                                        onClick = {
                                            currentState = currentState.copy(aspectRatio = ratio)
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // BOTTOM NAVIGATION TABS
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CineSurfaceVariant)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                VideoTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    val tint = if (isSelected) CineCyan else CineTextMuted

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedTab = tab }
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = tint,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = tab.title,
                            color = tint,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }

    // Export Progress Modal
    if (isExporting) {
        ProcessingDialog(
            title = "Exporting Video",
            progress = exportProgress,
            message = "Encoding MP4 with Media3 Transformer...",
            onCancel = {
                VideoExporter.cancelExport()
                isExporting = false
            }
        )
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
