package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkCinematicColorScheme =
  darkColorScheme(
    primary = CineAmber,
    onPrimary = Color.Black,
    primaryContainer = CineAmber.copy(alpha = 0.2f),
    onPrimaryContainer = CineAmberGlow,
    secondary = CineCyan,
    onSecondary = Color.Black,
    secondaryContainer = CineCyan.copy(alpha = 0.2f),
    onSecondaryContainer = CineCyanGlow,
    tertiary = CineRuby,
    onTertiary = Color.White,
    background = CineObsidian,
    onBackground = CineTextPrimary,
    surface = CineSurface,
    onSurface = CineTextPrimary,
    surfaceVariant = CineSurfaceVariant,
    onSurfaceVariant = CineTextSecondary,
    outline = CineBorder,
    outlineVariant = CineDivider,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Dark cinematic by default
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DarkCinematicColorScheme,
    typography = Typography,
    content = content
  )
}

