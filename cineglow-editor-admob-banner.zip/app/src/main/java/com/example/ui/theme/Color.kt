package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CineGlow Dark Cinematic Palette
val CineObsidian = Color(0xFF0C0D12)
val CineSurface = Color(0xFF141620)
val CineSurfaceVariant = Color(0xFF1E212E)
val CineSurfaceElevated = Color(0xFF272A3B)

val CineAmber = Color(0xFFFFB300)
val CineAmberGlow = Color(0xFFFFD54F)
val CineCyan = Color(0xFF00E5FF)
val CineCyanGlow = Color(0xFF80D8FF)
val CineRuby = Color(0xFFFF5252)

val CineTextPrimary = Color(0xFFF3F4F8)
val CineTextSecondary = Color(0xFFA5A9B8)
val CineTextMuted = Color(0xFF676C7F)
val CineBorder = Color(0xFF282C3D)
val CineDivider = Color(0xFF1E2230)

