package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CineFilter
import com.example.model.CropAspectRatio
import com.example.ui.theme.CineAmber
import com.example.ui.theme.CineAmberGlow
import com.example.ui.theme.CineBorder
import com.example.ui.theme.CineCyan
import com.example.ui.theme.CineObsidian
import com.example.ui.theme.CineSurface
import com.example.ui.theme.CineSurfaceElevated
import com.example.ui.theme.CineSurfaceVariant
import com.example.ui.theme.CineTextMuted
import com.example.ui.theme.CineTextPrimary
import com.example.ui.theme.CineTextSecondary

/**
 * Filter preset item card for horizontal filter selector.
 */
@Composable
fun FilterPresetItem(
    filter: CineFilter,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) CineAmber else CineBorder
    val borderWidth = if (isSelected) 2.dp else 1.dp
    val textColor = if (isSelected) CineAmberGlow else CineTextSecondary

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.verticalGradient(
                        colors = when (filter) {
                            CineFilter.ORIGINAL -> listOf(Color(0xFF333842), Color(0xFF1E2028))
                            CineFilter.CINEMATIC -> listOf(Color(0xFF00796B), Color(0xFFD84315))
                            CineFilter.DSLR -> listOf(Color(0xFF263238), Color(0xFF102027))
                            CineFilter.WARM -> listOf(Color(0xFFF57F17), Color(0xFFE65100))
                            CineFilter.COOL -> listOf(Color(0xFF0277BD), Color(0xFF00838F))
                            CineFilter.VIVID -> listOf(Color(0xFFC2185B), Color(0xFF7B1FA2))
                            CineFilter.VINTAGE -> listOf(Color(0xFF6D4C41), Color(0xFF3E2723))
                            CineFilter.BLACK_AND_WHITE -> listOf(Color(0xFFEEEEEE), Color(0xFF212121))
                            CineFilter.PORTRAIT -> listOf(Color(0xFFFF8A80), Color(0xFFFFAB91))
                        }
                    )
                )
                .border(borderWidth, borderColor, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = filter.displayName.take(3).uppercase(),
                color = if (filter == CineFilter.BLACK_AND_WHITE) Color.Black else Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = filter.displayName,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

/**
 * Adjustment slider control with icon, title, value text, and reset capability.
 */
@Composable
fun AdjustmentSliderRow(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    formatAsInt: Boolean = true
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (value != 0f) CineAmber else CineTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = title,
                    color = CineTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                val valueString = if (formatAsInt) {
                    if (value > 0) "+${value.toInt()}" else "${value.toInt()}"
                } else {
                    String.format("%.1f", value)
                }
                Text(
                    text = valueString,
                    color = if (value != 0f) CineAmberGlow else CineTextMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                if (value != 0f) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = { onValueChange(0f) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset",
                            tint = CineTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = CineAmber,
                activeTrackColor = CineAmber,
                inactiveTrackColor = CineSurfaceElevated
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Aspect ratio selector chip.
 */
@Composable
fun AspectRatioChip(
    aspectRatio: CropAspectRatio,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (isSelected) CineAmber else CineSurfaceVariant
    val textColor = if (isSelected) Color.Black else CineTextPrimary
    val border = if (isSelected) CineAmberGlow else CineBorder

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = aspectRatio.displayName,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/**
 * Fullscreen / modal loading and saving progress indicator.
 */
@Composable
fun ProcessingDialog(
    title: String,
    progress: Float? = null,
    message: String = "Please wait...",
    onCancel: (() -> Unit)? = null
) {
    Dialog(onDismissRequest = { onCancel?.invoke() }) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = CineSurface,
            tonalElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, CineBorder)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = title,
                    color = CineTextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(20.dp))

                if (progress != null) {
                    CircularProgressIndicator(
                        progress = { progress },
                        color = CineAmber,
                        trackColor = CineSurfaceElevated,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "${(progress * 100).toInt()}%",
                        color = CineAmberGlow,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    CircularProgressIndicator(
                        color = CineAmber,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = message,
                    color = CineTextSecondary,
                    fontSize = 13.sp
                )

                if (onCancel != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CineSurfaceElevated)
                            .clickable(onClick = onCancel)
                            .padding(horizontal = 18.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "Cancel",
                            color = CineTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
