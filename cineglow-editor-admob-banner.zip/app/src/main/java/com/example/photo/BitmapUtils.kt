package com.example.photo

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlin.math.max
import kotlin.math.min

object BitmapUtils {

    /**
     * Decodes a Bitmap from Uri safely without throwing OutOfMemoryError.
     * Downscales the image if it exceeds maxDimension (default 2048px).
     */
    suspend fun decodeSampledBitmapFromUri(
        context: Context,
        uri: Uri,
        maxDimension: Int = 2048
    ): Bitmap? = withContext(Dispatchers.IO) {
        try {
            // First decode bounds only
            var inputStream: InputStream? = context.contentResolver.openInputStream(uri) ?: return@withContext null
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            val srcWidth = options.outWidth
            val srcHeight = options.outHeight
            if (srcWidth <= 0 || srcHeight <= 0) return@withContext null

            // Calculate sample size
            var inSampleSize = 1
            var halfWidth = srcWidth
            var halfHeight = srcHeight
            while (halfWidth > maxDimension || halfHeight > maxDimension) {
                inSampleSize *= 2
                halfWidth /= 2
                halfHeight /= 2
            }

            // Decode actual bitmap
            inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val sampledBitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
            inputStream.close()

            sampledBitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Applies full pipeline of edits to bitmap:
     * 1. Rotation
     * 2. Crop according to aspect ratio
     * 3. Skin enhancement (if > 0)
     * 4. Color adjustments (brightness, contrast, saturation, warmth, filter)
     * 5. Sharpness filter (if > 0)
     */
    suspend fun processEditedBitmap(
        source: Bitmap,
        state: PhotoEditState
    ): Bitmap = withContext(Dispatchers.Default) {
        var current = source

        // 1. Rotation
        if (state.rotationDegrees % 360 != 0) {
            val matrix = Matrix().apply {
                postRotate(state.rotationDegrees.toFloat())
            }
            val rotated = Bitmap.createBitmap(
                current, 0, 0, current.width, current.height, matrix, true
            )
            current = rotated
        }

        // 2. Crop by Aspect Ratio
        state.aspectRatio.ratio?.let { targetRatio ->
            val srcW = current.width
            val srcH = current.height
            val currentRatio = srcW.toFloat() / srcH.toFloat()

            var cropW = srcW
            var cropH = srcH
            var cropX = 0
            var cropY = 0

            if (currentRatio > targetRatio) {
                // Too wide, crop sides
                cropW = (srcH * targetRatio).toInt().coerceAtMost(srcW)
                cropX = (srcW - cropW) / 2
            } else if (currentRatio < targetRatio) {
                // Too tall, crop top/bottom
                cropH = (srcW / targetRatio).toInt().coerceAtMost(srcH)
                cropY = (srcH - cropH) / 2
            }

            if (cropW > 0 && cropH > 0 && (cropW != srcW || cropH != srcH)) {
                val cropped = Bitmap.createBitmap(current, cropX, cropY, cropW, cropH)
                current = cropped
            }
        }

        // 3. Natural skin enhancement
        if (state.skinEnhance > 0f) {
            current = SkinEnhancer.enhance(current, state.skinEnhance)
        }

        // 4. ColorMatrix adjustments
        val cm = state.computeColorMatrix()
        val androidColorMatrix = android.graphics.ColorMatrix(cm.values)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(androidColorMatrix)
        }

        val coloredBitmap = Bitmap.createBitmap(current.width, current.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(coloredBitmap)
        canvas.drawBitmap(current, 0f, 0f, paint)
        current = coloredBitmap

        // 5. Sharpness (unsharp mask / high-pass blend)
        if (state.sharpness > 0f) {
            current = applySharpness(current, state.sharpness)
        }

        current
    }

    /**
     * Applies high-quality sharpness filter using 3x3 convolution kernel.
     */
    private fun applySharpness(source: Bitmap, sharpness: Float): Bitmap {
        val amount = (sharpness / 100f) * 0.8f // 0.0 to 0.8 strength
        val w = source.width
        val h = source.height

        val srcPixels = IntArray(w * h)
        source.getPixels(srcPixels, 0, w, 0, 0, w, h)
        val outPixels = IntArray(w * h)

        for (y in 0 until h) {
            val yOffset = y * w
            val yPrev = max(0, y - 1) * w
            val yNext = min(h - 1, y + 1) * w

            for (x in 0 until w) {
                val xPrev = max(0, x - 1)
                val xNext = min(w - 1, x + 1)

                val center = srcPixels[yOffset + x]
                val top = srcPixels[yPrev + x]
                val bottom = srcPixels[yNext + x]
                val left = srcPixels[yOffset + xPrev]
                val right = srcPixels[yOffset + xNext]

                val a = android.graphics.Color.alpha(center)

                // Laplacian edge detection
                val rC = android.graphics.Color.red(center)
                val rL = (rC * 4 - android.graphics.Color.red(top) - android.graphics.Color.red(bottom) -
                        android.graphics.Color.red(left) - android.graphics.Color.red(right))
                val newR = (rC + rL * amount).toInt().coerceIn(0, 255)

                val gC = android.graphics.Color.green(center)
                val gL = (gC * 4 - android.graphics.Color.green(top) - android.graphics.Color.green(bottom) -
                        android.graphics.Color.green(left) - android.graphics.Color.green(right))
                val newG = (gC + gL * amount).toInt().coerceIn(0, 255)

                val bC = android.graphics.Color.blue(center)
                val bL = (bC * 4 - android.graphics.Color.blue(top) - android.graphics.Color.blue(bottom) -
                        android.graphics.Color.blue(left) - android.graphics.Color.blue(right))
                val newB = (bC + bL * amount).toInt().coerceIn(0, 255)

                outPixels[yOffset + x] = android.graphics.Color.argb(a, newR, newG, newB)
            }
        }

        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(outPixels, 0, w, 0, 0, w, h)
        return result
    }

    /**
     * Saves the processed bitmap directly to the Android MediaStore Gallery.
     * Returns the content Uri of the saved picture or null on failure.
     */
    suspend fun saveImageToGallery(
        context: Context,
        bitmap: Bitmap,
        titlePrefix: String = "CineGlow"
    ): Uri? = withContext(Dispatchers.IO) {
        val fileName = "${titlePrefix}_${System.currentTimeMillis()}.jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CineGlow")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return@withContext null

        try {
            context.contentResolver.openOutputStream(uri)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 96, stream)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
            }

            uri
        } catch (e: Exception) {
            e.printStackTrace()
            // Clean up partial insert
            try {
                context.contentResolver.delete(uri, null, null)
            } catch (_: Exception) {}
            null
        }
    }
}
