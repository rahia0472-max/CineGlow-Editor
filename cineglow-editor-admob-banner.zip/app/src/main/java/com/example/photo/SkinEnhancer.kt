package com.example.photo

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/**
 * Natural skin-enhancement processor.
 *
 * Requirements:
 * - Smooth skin gently.
 * - Improve lighting and skin tone naturally.
 * - Do not change the person's identity or facial structure.
 * - Do not make unrealistic whitening effects.
 */
object SkinEnhancer {

    /**
     * Determines whether an RGB color falls within natural human skin chrominance.
     * Uses standardized YCbCr conversion:
     *   Y  =  0.299R + 0.587G + 0.114B
     *   Cb = -0.169R - 0.331G + 0.500B + 128
     *   Cr =  0.500R - 0.419G - 0.081B + 128
     * Natural human skin cluster: Cb in [77, 127], Cr in [133, 173].
     */
    fun isSkinTone(r: Int, g: Int, b: Int): Float {
        val cb = (-0.168736 * r - 0.331264 * g + 0.500000 * b + 128).toInt()
        val cr = (0.500000 * r - 0.418688 * g - 0.081312 * b + 128).toInt()

        // Check if within skin chrominance cluster with soft boundary falloff
        return if (cb in 75..128 && cr in 130..175 && r > g && g >= b && (r - b) >= 12) {
            // Distance from center of human skin chrominance (Cb ~ 102, Cr ~ 152)
            val dCb = (cb - 102).toFloat() / 26f
            val dCr = (cr - 152).toFloat() / 22f
            val distSq = dCb * dCb + dCr * dCr
            if (distSq < 1f) {
                1f - distSq * 0.3f
            } else if (distSq < 1.4f) {
                (1.4f - distSq) / 0.4f
            } else {
                0f
            }
        } else {
            0f
        }
    }

    /**
     * Applies gentle skin smoothing and natural warm lighting enhancement.
     *
     * @param source The input bitmap.
     * @param intensity 0f to 100f.
     * @return A new processed bitmap with natural skin enhancement.
     */
    fun enhance(source: Bitmap, intensity: Float): Bitmap {
        if (intensity <= 0f) return source

        val factor = (intensity / 100f).coerceIn(0f, 1f)
        val width = source.width
        val height = source.height

        val srcPixels = IntArray(width * height)
        source.getPixels(srcPixels, 0, width, 0, 0, width, height)

        val outPixels = IntArray(width * height)

        // Box blur kernel radius based on image dimension for consistent smoothness
        val radius = max(1, min(width, height) / 300)

        // Precompute horizontal integral for fast box smoothing
        val blurredPixels = fastBoxBlur(srcPixels, width, height, radius)

        for (i in 0 until width * height) {
            val src = srcPixels[i]
            val a = Color.alpha(src)
            val r = Color.red(src)
            val g = Color.green(src)
            val b = Color.blue(src)

            val skinConfidence = isSkinTone(r, g, b)

            if (skinConfidence > 0f) {
                val blur = blurredPixels[i]
                val br = Color.red(blur)
                val bg = Color.green(blur)
                val bb = Color.blue(blur)

                // Blend weight based on user intensity and skin tone confidence
                // Cap maximum blur blend at 65% so skin pores and facial structure are preserved
                val blendWeight = factor * skinConfidence * 0.65f

                // Gentle natural lighting improvement (slight 4-8% warm luminance lift, no white bleaching)
                val lightLift = 1f + (factor * skinConfidence * 0.06f)

                val smoothR = (r * (1f - blendWeight) + br * blendWeight) * lightLift
                val smoothG = (g * (1f - blendWeight) + bg * blendWeight) * (lightLift * 0.98f)
                val smoothB = (b * (1f - blendWeight) + bb * blendWeight) * (lightLift * 0.95f)

                val finalR = smoothR.toInt().coerceIn(0, 255)
                val finalG = smoothG.toInt().coerceIn(0, 255)
                val finalB = smoothB.toInt().coerceIn(0, 255)

                outPixels[i] = Color.argb(a, finalR, finalG, finalB)
            } else {
                // Keep non-skin features (eyes, hair, background, details) 100% untouched
                outPixels[i] = src
            }
        }

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        result.setPixels(outPixels, 0, width, 0, 0, width, height)
        return result
    }

    /**
     * Fast single-pass box blur for smooth skin blending without OOM.
     */
    private fun fastBoxBlur(pixels: IntArray, w: Int, h: Int, radius: Int): IntArray {
        val out = IntArray(w * h)
        val r = radius.coerceAtLeast(1)

        // Horizontal pass
        val temp = IntArray(w * h)
        for (y in 0 until h) {
            val rowOffset = y * w
            var sumR = 0
            var sumG = 0
            var sumB = 0
            var count = 0

            // Initialize window
            for (x in 0..min(r, w - 1)) {
                val p = pixels[rowOffset + x]
                sumR += Color.red(p)
                sumG += Color.green(p)
                sumB += Color.blue(p)
                count++
            }

            for (x in 0 until w) {
                temp[rowOffset + x] = Color.argb(255, sumR / count, sumG / count, sumB / count)

                // Add next right pixel
                val nextX = x + r + 1
                if (nextX < w) {
                    val p = pixels[rowOffset + nextX]
                    sumR += Color.red(p)
                    sumG += Color.green(p)
                    sumB += Color.blue(p)
                    count++
                }
                // Subtract left pixel
                val prevX = x - r
                if (prevX >= 0) {
                    val p = pixels[rowOffset + prevX]
                    sumR -= Color.red(p)
                    sumG -= Color.green(p)
                    sumB -= Color.blue(p)
                    count--
                }
            }
        }

        // Vertical pass
        for (x in 0 until w) {
            var sumR = 0
            var sumG = 0
            var sumB = 0
            var count = 0

            for (y in 0..min(r, h - 1)) {
                val p = temp[y * w + x]
                sumR += Color.red(p)
                sumG += Color.green(p)
                sumB += Color.blue(p)
                count++
            }

            for (y in 0 until h) {
                out[y * w + x] = Color.argb(255, sumR / count, sumG / count, sumB / count)

                val nextY = y + r + 1
                if (nextY < h) {
                    val p = temp[nextY * w + x]
                    sumR += Color.red(p)
                    sumG += Color.green(p)
                    sumB += Color.blue(p)
                    count++
                }
                val prevY = y - r
                if (prevY >= 0) {
                    val p = temp[prevY * w + x]
                    sumR -= Color.red(p)
                    sumG -= Color.green(p)
                    sumB -= Color.blue(p)
                    count--
                }
            }
        }

        return out
    }
}
