package com.example.photo

import androidx.compose.ui.graphics.ColorMatrix
import com.example.model.CineFilter
import com.example.model.CropAspectRatio

/**
 * Immutable state holding all photo adjustments.
 */
data class PhotoEditState(
    val filter: CineFilter = CineFilter.ORIGINAL,
    val brightness: Float = 0f,      // -100f to +100f
    val contrast: Float = 0f,        // -100f to +100f
    val saturation: Float = 0f,      // -100f to +100f
    val warmth: Float = 0f,          // -100f to +100f
    val sharpness: Float = 0f,       // 0f to 100f
    val highlights: Float = 0f,      // -100f to +100f
    val shadows: Float = 0f,         // -100f to +100f
    val skinEnhance: Float = 0f,     // 0f to 100f (natural skin smoothing & tone)
    val rotationDegrees: Int = 0,    // 0, 90, 180, 270
    val aspectRatio: CropAspectRatio = CropAspectRatio.ORIGINAL
) {
    fun isDefault(): Boolean {
        return filter == CineFilter.ORIGINAL &&
                brightness == 0f &&
                contrast == 0f &&
                saturation == 0f &&
                warmth == 0f &&
                sharpness == 0f &&
                highlights == 0f &&
                shadows == 0f &&
                skinEnhance == 0f &&
                rotationDegrees == 0 &&
                aspectRatio == CropAspectRatio.ORIGINAL
    }

    /**
     * Builds the complete combined ColorMatrix incorporating the selected filter,
     * brightness, contrast, saturation, warmth, and highlights/shadows.
     */
    fun computeColorMatrix(): ColorMatrix {
        val result = filter.getColorMatrix()

        // 1. Saturation adjustment
        if (saturation != 0f) {
            val satFactor = (saturation + 100f) / 100f // 0.0 to 2.0
            val satMatrix = ColorMatrix().apply { setToSaturation(satFactor) }
            result.timesAssign(satMatrix)
        }

        // 2. Contrast adjustment
        if (contrast != 0f) {
            val cScale = if (contrast > 0) 1f + (contrast / 100f) * 1.5f else 1f + (contrast / 100f) * 0.8f
            val cTranslate = (-0.5f * cScale + 0.5f) * 255f
            val contrastMatrix = ColorMatrix(
                floatArrayOf(
                    cScale, 0f, 0f, 0f, cTranslate,
                    0f, cScale, 0f, 0f, cTranslate,
                    0f, 0f, cScale, 0f, cTranslate,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            result.timesAssign(contrastMatrix)
        }

        // 3. Brightness, Warmth, Highlights/Shadows
        val bOffset = brightness * 1.5f
        val wRed = (warmth / 100f) * 25f
        val wBlue = -(warmth / 100f) * 25f
        val hlOffset = (highlights / 100f) * 15f
        val shOffset = (shadows / 100f) * 15f

        val totalRedOffset = bOffset + wRed + hlOffset + shOffset
        val totalGreenOffset = bOffset + hlOffset + (shOffset * 0.8f)
        val totalBlueOffset = bOffset + wBlue + (hlOffset * 0.6f) + shOffset

        if (totalRedOffset != 0f || totalGreenOffset != 0f || totalBlueOffset != 0f) {
            val offsetMatrix = ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, totalRedOffset,
                    0f, 1f, 0f, 0f, totalGreenOffset,
                    0f, 0f, 1f, 0f, totalBlueOffset,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            result.timesAssign(offsetMatrix)
        }

        return result
    }
}
