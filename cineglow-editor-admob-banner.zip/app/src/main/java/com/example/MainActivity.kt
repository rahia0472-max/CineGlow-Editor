package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.ads.AdMobManager
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PhotoEditorScreen
import com.example.ui.screens.VideoEditorScreen
import com.example.ui.theme.MyApplicationTheme

sealed class AppScreen {
    data object Home : AppScreen()
    data class PhotoEditor(val uri: Uri) : AppScreen()
    data class VideoEditor(val uri: Uri) : AppScreen()
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize AdMob safely
        AdMobManager.initialize(this)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CineGlowApp()
                }
            }
        }
    }
}

@Composable
fun CineGlowApp() {
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Home) }

    // Request permissions launcher for older Android versions
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Permissions handled
    }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    // Handle back button behavior
    if (currentScreen !is AppScreen.Home) {
        BackHandler {
            currentScreen = AppScreen.Home
        }
    }

    when (val screen = currentScreen) {
        is AppScreen.Home -> {
            HomeScreen(
                onPhotoSelected = { uri ->
                    currentScreen = AppScreen.PhotoEditor(uri)
                },
                onVideoSelected = { uri ->
                    currentScreen = AppScreen.VideoEditor(uri)
                }
            )
        }

        is AppScreen.PhotoEditor -> {
            PhotoEditorScreen(
                initialUri = screen.uri,
                onNavigateBack = {
                    currentScreen = AppScreen.Home
                }
            )
        }

        is AppScreen.VideoEditor -> {
            VideoEditorScreen(
                initialUri = screen.uri,
                onNavigateBack = {
                    currentScreen = AppScreen.Home
                }
            )
        }
    }
}

/**
 * Maintained for test compatibility.
 */
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
