package com.example.model

import androidx.compose.ui.graphics.ColorMatrix

/**
 * Filter presets for both Photo and Video editing in CineGlow Editor.
 */
enum class CineFilter(val displayName: String, val description: String) {
    ORIGINAL("Original", "Natural untouched look"),
    CINEMATIC("Cinematic", "Teal & orange film grade"),
    DSLR("DSLR", "Crisp clarity & deep contrast"),
    WARM("Warm", "Golden hour sunset glow"),
    COOL("Cool", "Arctic cyan & film chill"),
    VIVID("Vivid", "High saturation & vibrant colors"),
    VINTAGE("Vintage", "Retro faded warm sepia tone"),
    BLACK_AND_WHITE("B & W", "High contrast silver monochrome"),
    PORTRAIT("Portrait", "Soft flattering skin tones");

    /**
     * Builds a 4x5 ColorMatrix representing this filter's color transformation.
     */
    fun getColorMatrix(): ColorMatrix {
        return when (this) {
            ORIGINAL -> {
                ColorMatrix().apply { reset() }
            }
            CINEMATIC -> {
                // Teal shadows, warm amber highlights
                ColorMatrix(
                    floatArrayOf(
                        1.15f, 0.05f, 0.00f, 0.0f, 15f,
                        0.05f, 1.05f, 0.10f, 0.0f, 5f,
                        -0.05f, 0.10f, 1.25f, 0.0f, -10f,
                        0.0f, 0.0f, 0.0f, 1.0f, 0f
                    )
                )
            }
            DSLR -> {
                // Punchy contrast, crisp black points, slight saturation boost
                val scale = 1.25f
                val translate = (-0.5f * scale + 0.5f) * 255f
                ColorMatrix(
                    floatArrayOf(
                        scale * 1.05f, 0.0f, 0.0f, 0.0f, translate + 5f,
                        0.0f, scale * 1.05f, 0.0f, 0.0f, translate + 5f,
                        0.0f, 0.0f, scale * 1.05f, 0.0f, translate + 5f,
                        0.0f, 0.0f, 0.0f, 1.0f, 0f
                    )
                )
            }
            WARM -> {
                // Golden warmth, boosted reds and yellows
                ColorMatrix(
                    floatArrayOf(
                        1.20f, 0.0f, 0.0f, 0.0f, 20f,
                        0.0f, 1.10f, 0.0f, 0.0f, 10f,
                        0.0f, 0.0f, 0.90f, 0.0f, -15f,
                        0.0f, 0.0f, 0.0f, 1.0f, 0f
                    )
                )
            }
            COOL -> {
                // Cool arctic cyan / blue tone
                ColorMatrix(
                    floatArrayOf(
                        0.90f, 0.0f, 0.0f, 0.0f, -15f,
                        0.0f, 1.05f, 0.0f, 0.0f, 5f,
                        0.0f, 0.0f, 1.25f, 0.0f, 25f,
                        0.0f, 0.0f, 0.0f, 1.0f, 0f
                    )
                )
            }
            VIVID -> {
                // High vibrance, boosted saturation
                val cm = ColorMatrix().apply { setToSaturation(1.45f) }
                val contrastScale = 1.12f
                val translate = (-0.5f * contrastScale + 0.5f) * 255f
                val contrastMatrix = ColorMatrix(
                    floatArrayOf(
                        contrastScale, 0f, 0f, 0f, translate,
                        0f, contrastScale, 0f, 0f, translate,
                        0f, 0f, contrastScale, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                cm.timesAssign(contrastMatrix)
                cm
            }
            VINTAGE -> {
                // Nostalgic faded sepia, lifted black levels
                ColorMatrix(
                    floatArrayOf(
                        0.95f, 0.15f, 0.05f, 0.0f, 25f,
                        0.10f, 0.85f, 0.10f, 0.0f, 18f,
                        0.05f, 0.15f, 0.70f, 0.0f, 10f,
                        0.0f, 0.0f, 0.0f, 1.0f, 0f
                    )
                )
            }
            BLACK_AND_WHITE -> {
                // Rich high-contrast silver monochrome
                val r = 0.299f
                val g = 0.587f
                val b = 0.114f
                val c = 1.18f
                val tr = (-0.5f * c + 0.5f) * 255f
                ColorMatrix(
                    floatArrayOf(
                        r * c, g * c, b * c, 0f, tr,
                        r * c, g * c, b * c, 0f, tr,
                        r * c, g * c, b * c, 0f, tr,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }
            PORTRAIT -> {
                // Gentle luminous skin warmth and soft highlights
                ColorMatrix(
                    floatArrayOf(
                        1.08f, 0.02f, 0.00f, 0.0f, 12f,
                        0.02f, 1.04f, 0.02f, 0.0f, 8f,
                        0.00f, 0.02f, 0.98f, 0.0f, -4f,
                        0.0f, 0.0f, 0.0f, 1.0f, 0f
                    )
                )
            }
        }
    }
}

/**
 * Supported aspect ratios for photo and video crops.
 */
enum class CropAspectRatio(val displayName: String, val ratio: Float?) {
    ORIGINAL("Original", null),
    RATIO_1_1("1:1", 1.0f),
    RATIO_4_5("4:5", 4f / 5f),
    RATIO_9_16("9:16", 9f / 16f)
}
