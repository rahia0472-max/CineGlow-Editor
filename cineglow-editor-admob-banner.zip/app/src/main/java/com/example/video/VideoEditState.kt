package com.example.video

import android.net.Uri
import androidx.compose.ui.graphics.ColorMatrix
import com.example.model.CineFilter
import com.example.model.CropAspectRatio

/**
 * Immutable state holding video editing parameters.
 */
data class VideoEditState(
    val uri: Uri? = null,
    val durationMs: Long = 0L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val filter: CineFilter = CineFilter.ORIGINAL,
    val brightness: Float = 0f,   // -100f to +100f
    val contrast: Float = 0f,     // -100f to +100f
    val saturation: Float = 0f,   // -100f to +100f
    val aspectRatio: CropAspectRatio = CropAspectRatio.ORIGINAL
) {
    /**
     * Builds color matrix for live video preview filtering in Compose.
     */
    fun computeColorMatrix(): ColorMatrix {
        val result = filter.getColorMatrix()

        if (saturation != 0f) {
            val satFactor = (saturation + 100f) / 100f
            val satMatrix = ColorMatrix().apply { setToSaturation(satFactor) }
            result.timesAssign(satMatrix)
        }

        if (contrast != 0f) {
            val cScale = if (contrast > 0) 1f + (contrast / 100f) * 1.5f else 1f + (contrast / 100f) * 0.8f
            val cTranslate = (-0.5f * cScale + 0.5f) * 255f
            val contrastMatrix = ColorMatrix(
                floatArrayOf(
                    cScale, 0f, 0f, 0f, cTranslate,
                    0f, cScale, 0f, 0f, cTranslate,
                    0f, 0f, cScale, 0f, cTranslate,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            result.timesAssign(contrastMatrix)
        }

        if (brightness != 0f) {
            val bOffset = brightness * 1.5f
            val bMatrix = ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, bOffset,
                    0f, 1f, 0f, 0f, bOffset,
                    0f, 0f, 1f, 0f, bOffset,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            result.timesAssign(bMatrix)
        }

        return result
    }
}
