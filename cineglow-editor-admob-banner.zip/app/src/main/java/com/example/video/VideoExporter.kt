package com.example.video

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.model.CineFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

object VideoExporter {

    private var activeTransformer: Transformer? = null
    private var progressRunnable: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())

    fun cancelExport() {
        handler.removeCallbacksAndMessages(null)
        try {
            activeTransformer?.cancel()
        } catch (_: Exception) {}
        activeTransformer = null
    }

    /**
     * Exports a trimmed, filtered, and aspect-ratio adjusted video via Media3 Transformer.
     * Progress is reported via onProgress (0f to 1f).
     * The resulting MP4 is saved directly into Android MediaStore Movies/CineGlow.
     */
    fun exportVideo(
        context: Context,
        state: VideoEditState,
        onProgress: (Float) -> Unit,
        onSuccess: (Uri) -> Unit,
        onError: (String) -> Unit
    ) {
        val inputUri = state.uri ?: run {
            onError("No input video selected.")
            return
        }

        val cacheDir = context.cacheDir
        val tempOutputFile = File(cacheDir, "cineglow_export_${System.currentTimeMillis()}.mp4")

        // 1. Build clipping configuration for trim
        val clippingBuilder = MediaItem.ClippingConfiguration.Builder()
        if (state.trimStartMs > 0L) {
            clippingBuilder.setStartPositionMs(state.trimStartMs)
        }
        if (state.trimEndMs > 0L && state.trimEndMs < state.durationMs) {
            clippingBuilder.setEndPositionMs(state.trimEndMs)
        }

        val mediaItem = MediaItem.Builder()
            .setUri(inputUri)
            .setClippingConfiguration(clippingBuilder.build())
            .build()

        // 2. Build video effects list
        val videoEffects = mutableListOf<Effect>()

        // Aspect ratio presentation effect
        state.aspectRatio.ratio?.let { targetRatio ->
            try {
                videoEffects.add(
                    Presentation.createForAspectRatio(targetRatio, Presentation.LAYOUT_SCALE_TO_FIT)
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Contrast adjustment
        if (state.contrast != 0f) {
            try {
                val cVal = (state.contrast / 100f).coerceIn(-1f, 1f)
                videoEffects.add(Contrast(cVal))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Saturation adjustment
        if (state.saturation != 0f) {
            try {
                val satAdjustment = state.saturation.coerceIn(-100f, 100f)
                videoEffects.add(
                    HslAdjustment.Builder().adjustSaturation(satAdjustment).build()
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Brightness / Filter specific RGB tint
        val bFactor = (state.brightness / 100f) * 0.3f
        when (state.filter) {
            CineFilter.WARM -> {
                videoEffects.add(
                    RgbAdjustment.Builder()
                        .setRedScale(1.15f + bFactor)
                        .setGreenScale(1.05f + bFactor)
                        .setBlueScale(0.90f + bFactor)
                        .build()
                )
            }
            CineFilter.COOL -> {
                videoEffects.add(
                    RgbAdjustment.Builder()
                        .setRedScale(0.90f + bFactor)
                        .setGreenScale(1.05f + bFactor)
                        .setBlueScale(1.20f + bFactor)
                        .build()
                )
            }
            CineFilter.CINEMATIC -> {
                videoEffects.add(
                    RgbAdjustment.Builder()
                        .setRedScale(1.12f + bFactor)
                        .setGreenScale(1.02f + bFactor)
                        .setBlueScale(0.95f + bFactor)
                        .build()
                )
            }
            CineFilter.DSLR -> {
                videoEffects.add(
                    RgbAdjustment.Builder()
                        .setRedScale(1.05f + bFactor)
                        .setGreenScale(1.05f + bFactor)
                        .setBlueScale(1.05f + bFactor)
                        .build()
                )
            }
            CineFilter.BLACK_AND_WHITE -> {
                // Completely desaturate to achieve monochrome
                videoEffects.add(
                    HslAdjustment.Builder().adjustSaturation(-100f).build()
                )
            }
            CineFilter.VIVID -> {
                videoEffects.add(
                    HslAdjustment.Builder().adjustSaturation(45f).build()
                )
            }
            else -> {
                if (bFactor != 0f) {
                    videoEffects.add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f + bFactor)
                            .setGreenScale(1f + bFactor)
                            .setBlueScale(1f + bFactor)
                            .build()
                    )
                }
            }
        }

        val editedMediaItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        // 3. Build Transformer
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null)
                    activeTransformer = null

                    // Save output file to MediaStore gallery
                    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                        val savedUri = saveVideoToGallery(context, tempOutputFile)
                        tempOutputFile.delete()

                        withContext(Dispatchers.Main) {
                            if (savedUri != null) {
                                onSuccess(savedUri)
                            } else {
                                onError("Failed to save exported video to Gallery.")
                            }
                        }
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacksAndMessages(null)
                    activeTransformer = null
                    tempOutputFile.delete()
                    val msg = exportException.localizedMessage ?: "Video export error"
                    onError(msg)
                }
            })
            .build()

        activeTransformer = transformer

        try {
            transformer.start(editedMediaItem, tempOutputFile.absolutePath)
        } catch (e: Exception) {
            activeTransformer = null
            tempOutputFile.delete()
            onError("Could not start export: ${e.message}")
            return
        }

        // 4. Poll progress smoothly
        val progressHolder = ProgressHolder()
        progressRunnable = object : Runnable {
            override fun run() {
                val currentTransformer = activeTransformer
                if (currentTransformer != null) {
                    val progressState = currentTransformer.getProgress(progressHolder)
                    if (progressState == Transformer.PROGRESS_STATE_AVAILABLE) {
                        val fraction = (progressHolder.progress.toFloat() / 100f).coerceIn(0f, 1f)
                        onProgress(fraction)
                    }
                    handler.postDelayed(this, 150)
                }
            }
        }
        handler.post(progressRunnable!!)
    }

    /**
     * Saves exported MP4 into the device's Movies/CineGlow directory via MediaStore.
     */
    private suspend fun saveVideoToGallery(context: Context, sourceFile: File): Uri? =
        withContext(Dispatchers.IO) {
            val fileName = "CineGlow_${System.currentTimeMillis()}.mp4"

            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/CineGlow")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }

            val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return@withContext null

            try {
                context.contentResolver.openOutputStream(uri)?.use { outStream ->
                    FileInputStream(sourceFile).use { inStream ->
                        inStream.copyTo(outStream)
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                }

                uri
            } catch (e: Exception) {
                e.printStackTrace()
                try {
                    context.contentResolver.delete(uri, null, null)
                } catch (_: Exception) {}
                null
            }
        }
}
